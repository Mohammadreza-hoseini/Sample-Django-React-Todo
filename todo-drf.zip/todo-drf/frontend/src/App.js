import React from 'react';
import './App.css';

class App extends React.Component {

  state = {
    todoList:[],
    activeItem:{
      id:null,
      title:'',
      completed:false,
    },
    editing:false,
  }

  componentDidMount = () => {
    this.fetchTasks()
  }

  // django document
  getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

fetchTasks = () => {
  fetch('http://127.0.0.1:8000/api/task-list/')
  .then(response => response.json())
  .then(data => this.setState({ todoList:data }) )
}

changeHandler = (e) => {
  let value = e.target.value
  this.setState({ 
    activeItem:{
      ...this.state.activeItem,
      title:value
    }
   })
}

submitHandler = (e) => {
  e.preventDefault()
  if (this.state.activeItem.title === '') {
    alert('please write note')
    return false

  }
  else{

    const csrftoken = this.getCookie('csrftoken');
    let url = 'http://127.0.0.1:8000/api/task-create/'

    if (this.state.editing == true) {
      url = `http://127.0.0.1:8000/api/task-update/${this.state.activeItem.id}/`
      this.setState({ 
        editing:false
       })
    }

    fetch(url,{
      method:'POST',
      headers:{
        'Content-type' : 'application/json',
        'X-CSRFToken' : csrftoken,
      },
      body:JSON.stringify(this.state.activeItem)
    }).then((response) => {
      this.fetchTasks()
      this.setState({activeItem:{
        id:null,
        title:'',
        completed:false,
      }
    })
    }).catch((error) => {console.log(error)})
    }
}

startEdit = (task) => {
  this.setState({ activeItem:{
    id:task.id,
    title:task.title,
    completed:false,
  },
    editing:true,
  
  })
}

deleteItem = (task) => {
  const csrftoken = this.getCookie('csrftoken');
  fetch(`http://127.0.0.1:8000/api/task-delete/${task.id}/` , {
    method:'DELETE',
    headers:{
      'Content-type' : 'application/json',
        'X-CSRFToken' : csrftoken,
    },
  }).then((response) =>{
    this.fetchTasks()
  })
}




strikeUnstrike = (task,e) => {

  if (e.target.tagName == 'BUTTON') {
    return false
  }else{
      task.completed = !task.completed
    const csrftoken = this.getCookie('csrftoken');
    let url = `http://127.0.0.1:8000/api/task-update/${task.id}/`
    fetch(url,{
      method:'POST',
      headers:{
        'Content-type' : 'application/json',
          'X-CSRFToken' : csrftoken,
      },
      body:JSON.stringify({'completed':task.completed,'title':task.title})
    }).then(() => {
      this.fetchTasks()
    })
  }
  
}




  render () {
    let tasks = this.state.todoList
    return(
      <div className="container">
        <div id="task-container">
          <div id="form-wrapper">
            <form onSubmit={this.submitHandler}  id="form">
                      <div className="flex-wrapper">
                          <div style={{flex: 6}}>
                              <input onChange={this.changeHandler} className="form-control" id="title" value={this.state.activeItem.title}  type="text" name="title" placeholder="Add task.." />
                          </div>

                          <div style={{flex: 1}}>
                              <input id="submit" className="btn btn-warning" type="submit" name="Add" />
                            </div>
                        </div>
              </form>
          </div>

          <div id="list-wrapper">
                { tasks.map((item,index) => {
                  return(
                    <div onClick={(e) => {this.strikeUnstrike(item,e)}} key={index} className="task-wrapper flex-wrapper" >
                        <div style={{ flex:7 }}>

                          {item.completed == false ? (
                            <span>{item.title}</span>
                          ) : (
                            <strike>{item.title}</strike>
                          )}

                          
                        </div>
                        <div style={{ flex:1 }}>
                          <button onClick={() => this.startEdit(item) } className="btn btn-sm btn-outline-info">Edit</button>
                        </div>
                        <div style={{ flex:1 }}>
                        <button onClick={ () => this.deleteItem(item) } className="btn btn-sm btn-outline-dark delete">Delete</button>
                        </div>
                    </div>
                  )
                }) }
          </div>
        </div>
      </div>
    )
  }
}

export default App;
